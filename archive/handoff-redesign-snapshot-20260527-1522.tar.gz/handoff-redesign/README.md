# handoff-redesign — user quick start

> ⚠️ **本 plan は Claude Design の Pro / Max / Team / Enterprise subscription を前提とします**。subscription 不在の場合は本 plan は起動不能、別案 (Claude Code 単独 React 化) に切替えてください。

> ⚠️ **Hub pilot gate**: Step 2 (01-hub) の Acceptance check が全部 pass し、Step 4 (handoff bundle 取得) で bundle file 構造が観察できるまで、**残 5 画面 (02 〜 06) に進まないでください**。Hub の観察結果を `00-shared/hub-pilot-findings.md` に書いた後、**Step 2.6 で `hub-pilot-findings.md` を Claude Code に渡し、02-06 prompt を一括 patch** してください (本 plan の prompt は Hub 観察前の仮説に基づくため、user 自身で手修正せず Claude Code に戻す動線を取ります)。

---

## このディレクトリの目的

`backoffice-ai-v2/prototype/` (9 画面) の 3 つの認知負荷問題:

1. 文字が多すぎる (Dashboard 1 viewport で ~45 text token block)
2. 一目で何をしたら良いか分からない (primary action が 3 並列)
3. 画面ごとレイアウト不統一 (3 typology / 5 variant)

これを **9 画面 → 6 画面 (Hub / Queue / CaseDetail / ProposalDetail / AgentDetail / Observatory)** に再編し、Claude Design (claude.ai/design) で wireframe → polished mockup を作成、Claude Code で React 化 (prototype-redesign/) する 3 段階 plan の **Phase 0 = visual 作成準備の pack**。

詳細 plan: `~/.claude/plans/hashed-conjuring-spark.md`

---

## Phase 全体像

| Phase | 実行主体 | 内容 |
|---|---|---|
| Phase 0 | (済) | 本 pack 作成 |
| **Phase 1A (Hub pilot)** | **user → claude.ai/design** | Hub 1 画面で wireframe + mockup + handoff bundle を試す |
| Phase 1B (patch 反映) | user → Claude Code | hub-pilot-findings を Claude Code に渡し 02-06 prompt 一括 patch |
| Phase 1C (残 5 画面) | user → claude.ai/design | 02-06 を順次 wireframe + mockup |
| Phase 2 | Claude Code (別 plan) | `prototype-redesign/` で React 化 |

---

## Step 1: Design system 登録 (1 度のみ、約 5 分)

1. claude.ai/design を開き、新規 project を作成
2. `00-shared/design-system.md` を全選択 + paste
3. paste 直前に「以下を design system spec として登録してください」と前置きしておく
4. Claude Design が design system を受領したことを確認 (project の Style / Tokens panel に値が反映されればOK)

## Step 1.5: 一度だけ upload (約 3-5 分)

1. `00-shared/upload-once/README.md` を読み、upload 順を確認
2. 配下の 4 必須 file を順に upload:
   - `operational-premium-light-contact-sheet.md`
   - `charter-summary.md`
   - `research-compounder-refs.md`
   - `prototype-current-reference.md` (旧 9 画面の visual inventory、最重要)
3. (optional) 旧 prototype の screenshot を取得済みなら `prototype-screenshot-*.png` を一緒に upload

## Step 2: Hub pilot (01-hub のみ、約 20-40 分)

1. `01-hub/prompt-wireframe.md` を全選択 + paste
   - **Claude Design UI に "wireframe / mockup" の mode 切替 pill が見つかった場合: UI の mode 切替を優先**してください。本 prompt の `Requested output style:` 1 行は補助です
2. 生成された wireframe を確認、prompt 末尾の Acceptance check 5 個を visual で判定
3. NG なら Claude Design の inline edit / adjustment knobs で修正、OK なら export
4. Export を `01-hub/wireframe-output.html` (or `.pdf`) として保存
5. 同 conversation 内で `01-hub/prompt-mockup.md` を全選択 + paste (previous wireframe を継承する想定)
6. 生成された polished mockup の Acceptance check を判定
7. OK なら export を `01-hub/mockup-output.html` (or `.pdf`) として保存
8. Claude Design の "Send to Claude Code" を試し、handoff bundle を `99-claude-code-handoff/bundle/01-hub/` に保存
   - bundle 取得の UI 動線 / 結果 file 構造はここで初観察

## Step 2.5: Hub pilot findings 記録 (5 分、必須)

`00-shared/hub-pilot-findings.md` を開き、template に従って以下を記録:

- Claude Design UI に固定 mode pill があったか / なかったか (UI スクショ optional)
- 1 paste の文字数制限に当たったか (当たった場合、どう分割したか)
- Acceptance check は visual で判定可能だったか
- handoff bundle の file 構造はどうだったか (file 一覧、各 file の目的)
- 02-queue 以降の prompt に必要な軽量修正があるか

**このファイルが空のまま 02 以降に進まないでください**。

## Step 2.6: 02-06 prompt を Claude Code に一括 patch 依頼 (必須、約 5-10 分)

user が手で 02-06 prompt を修正する代わりに、Claude Code に**戻して**一括 patch する動線を取ります (認知負荷軽減目的):

1. Claude Code 新 session を起動
2. `99-claude-code-handoff/phase-1b-patch-instructions.md` を開き、中身を全選択 + paste
3. Claude Code が `00-shared/hub-pilot-findings.md` を読み、02-06 の `prompt-wireframe.md` / `prompt-mockup.md` (計 10 file) を一括 patch
4. Patch 完了後、本 README の Step 3 (残 5 画面) に進む

## Step 3: 残 5 画面 (02 〜 06、各画面 15-30 分)

Step 2.6 で patch された prompt を使って、02 〜 06 を Step 2 と同手順で進めます:

1. 02-queue → 03-case-detail → 04-proposal-detail → 05-agent-detail → 06-observatory の順
2. 各画面で `prompt-wireframe.md` → wireframe export → `prompt-mockup.md` → mockup export → handoff bundle 保存

## Step 4: 6 画面の handoff bundle 整理 (5 分)

`99-claude-code-handoff/bundle/` 配下に 01-hub 〜 06-observatory の bundle が揃っていることを確認:

```
99-claude-code-handoff/bundle/
├── 01-hub/
├── 02-queue/
├── 03-case-detail/
├── 04-proposal-detail/
├── 05-agent-detail/
└── 06-observatory/
```

## Step 5: Claude Code に Phase 2 依頼 (新 session)

`99-claude-code-handoff/phase-2-instructions.md` を開き、依頼文を Claude Code 新 session に paste。

---

## トラブルシュート

| 症状 | 対処 |
|---|---|
| 1 paste で文字数制限に当たる | prompt 末尾の Anti-pattern + Acceptance check を 2 nd message に分割。各 section は独立に書いてあるので分割可能 |
| Claude Design が design system 適用に失敗 | Step 1 の `design-system.md` paste 前置きを「以下を design system spec として恒久登録」と明示。codebase 自動読込 default が失敗した場合の fallback |
| mode 切替 UI が見つからない | `Requested output style:` の prompt header だけで意図は伝わるはず。Hub pilot で UI の有無を観察し、`hub-pilot-findings.md` に記録 |
| Acceptance check の visual 判定が曖昧 | Claude Design の inline edit で 1 element ずつ確認、unclear なら `hub-pilot-findings.md` に "判定不能" として記録し Step 2.6 で Claude Code に Acceptance check の言語を patch させる |
| handoff bundle が "Send to Claude Code" で生成されない | bundle 取得方法を `hub-pilot-findings.md` に "未取得、UI 動線 unknown" と記録、Step 2.6 で Claude Code に next-best representation (HTML export + 構造説明) への切替を相談 |
| subscription 未取得 | Pro / Max / Team / Enterprise いずれかを取得するか、本 plan を打ち切って別案 (Claude Code 単独 React 化、旧 plan revision に戻る) に切替 |

---

## ディレクトリ構造

```
handoff-redesign/
├── README.md                                  # 本 file
├── .gitignore                                 # export / bundle のみ ignore
├── 00-shared/                                 # 全画面共通 preamble
│   ├── design-system.md                       # Step 1 で paste
│   ├── ia-overview.md
│   ├── disclosure-rules.md
│   ├── jp-vocabulary.md
│   ├── visual-reference.md
│   ├── hub-pilot-findings.md                  # template、Step 2.5 で記入
│   └── upload-once/                           # Step 1.5 で upload
│       ├── README.md
│       ├── operational-premium-light-contact-sheet.md
│       ├── charter-summary.md
│       ├── research-compounder-refs.md
│       └── prototype-current-reference.md
├── 01-hub/                                    # Hub pilot 対象 (Phase 1A)
│   ├── prompt-wireframe.md
│   ├── prompt-mockup.md
│   └── spec.md
├── 02-queue/ ... 06-observatory/              # 残 5 画面 (Phase 1B/1C)、Step 2.6 で patch される
└── 99-claude-code-handoff/
    ├── phase-1b-patch-instructions.md         # Step 2.6 で paste
    ├── phase-2-instructions.md                # Step 5 で paste
    └── target-structure.md                    # Phase 2 で参照
```
